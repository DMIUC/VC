#define LDAC     0 // Arduino pin 8
#define CS_DAC   1 // Arduino pin 9
#define CS_ADC   2 // Arduino pin 10
#define DATAOUT  3 // Arduino pin 11
#define DATAIN   4 // Arduino pin 12
#define SPICLOCK 5 // Arduino pin 13
